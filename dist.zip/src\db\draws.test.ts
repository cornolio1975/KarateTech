import { describe, it, expect, beforeEach } from 'vitest';

// Mock window and localStorage globally BEFORE importing mockStore.
const store: Record<string, string> = {};
globalThis.window = {} as any;
globalThis.localStorage = {
  getItem: (key: string) => store[key] || null,
  setItem: (key: string, value: string) => { store[key] = value; },
  removeItem: (key: string) => { delete store[key]; },
  clear: () => {
    for (const key in store) {
      delete store[key];
    }
  },
  length: 0,
  key: (index: number) => null,
} as any;

// Now import mockStore and types
import { mockStore } from './mockStore';
import { Participant, ParticipantCategory, Bout } from './types';

// Helper to create participants
function createParticipants(count: number): Participant[] {
  const list: Participant[] = [];
  for (let i = 1; i <= count; i++) {
    list.push({
      id: `part-${i}`,
      registration_no: `REG-00${i}`,
      photo_url: '',
      full_name: `Athlete ${i}`,
      gender: 'Male',
      dob: '2000-01-01',
      nationality_code: 'MAS',
      passport_ic: `IC-00${i}`,
      email: `athlete${i}@example.com`,
      phone: '123456',
      emergency_contact_name: 'Emergency',
      emergency_contact_phone: '654321',
      club_id: 'club-1',
      coach_id: 'coach-1',
      weight: 60.0,
      height: 170.0,
      status: 'Confirmed',
      medical_status: 'Cleared',
      payment_status: 'Paid',
      remarks: '',
      created_at: new Date().toISOString()
    });
  }
  return list;
}

// Helper to map participants to a category
function createMappings(participantIds: string[], catId: string): ParticipantCategory[] {
  return participantIds.map((pId, idx) => ({
    id: `pc-${idx}`,
    participant_id: pId,
    category_id: catId,
    manual_override: false
  }));
}

describe('Karate Tournament Draw Generator Tests', () => {
  const catId = 'cat-test';

  beforeEach(() => {
    localStorage.clear();
  });

  describe('Validation & Edge Cases', () => {
    it('throws error when there are no active participants in category', () => {
      localStorage.setItem('ts_participants', JSON.stringify([]));
      localStorage.setItem('ts_participant_categories', JSON.stringify([]));

      expect(() => {
        mockStore.bouts.generateDraw(catId, 'Elimination', false);
      }).toThrowError('Cannot generate draws: No active participants in this category.');
    });

    it('filters out cancelled and deleted participants', () => {
      const participants = createParticipants(3);
      // Cancel participant 2, mark participant 3 as deleted
      participants[1].status = 'Cancelled';
      participants[2].deleted_at = new Date().toISOString();

      const mappings = createMappings(participants.map(p => p.id), catId);

      localStorage.setItem('ts_participants', JSON.stringify(participants));
      localStorage.setItem('ts_participant_categories', JSON.stringify(mappings));

      // This should generate draw for 1 active participant
      const bouts = mockStore.bouts.generateDraw(catId, 'Elimination', false);
      
      // For 1 active participant (power of 2 is 2 slots -> 1 bout in round 1)
      expect(bouts.length).toBe(1);
      // The single bout should be a Walkover since part-2 is cancelled/inactive
      expect(bouts[0].participant_a_id).toBe('part-1');
      expect(bouts[0].participant_b_id).toBeNull();
      expect(bouts[0].status).toBe('Walkover');
      expect(bouts[0].winner_id).toBe('part-1');
    });
  });

  describe('Round-robin Draw Type', () => {
    it('generates N * (N - 1) / 2 bouts for N participants', () => {
      const athleteCount = 4;
      const participants = createParticipants(athleteCount);
      const mappings = createMappings(participants.map(p => p.id), catId);

      localStorage.setItem('ts_participants', JSON.stringify(participants));
      localStorage.setItem('ts_participant_categories', JSON.stringify(mappings));

      const bouts = mockStore.bouts.generateDraw(catId, 'Round-robin', false);

      // 4 * 3 / 2 = 6 bouts
      expect(bouts.length).toBe(6);

      // Verify structure of the generated bouts
      bouts.forEach((bout) => {
        expect(bout.category_id).toBe(catId);
        expect(bout.round_no).toBe(1);
        expect(bout.status).toBe('Scheduled');
        expect(bout.winner_id).toBeNull();
        expect(bout.score_a).toBe(0);
        expect(bout.score_b).toBe(0);
      });

      // Verify every combination exists exactly once
      const matches = bouts.map(b => [b.participant_a_id, b.participant_b_id].sort().join('-'));
      expect(matches).toContain('part-1-part-2');
      expect(matches).toContain('part-1-part-3');
      expect(matches).toContain('part-1-part-4');
      expect(matches).toContain('part-2-part-3');
      expect(matches).toContain('part-2-part-4');
      expect(matches).toContain('part-3-part-4');
      expect(new Set(matches).size).toBe(6);
    });
  });

  describe('Elimination Draw Type', () => {
    it('generates a 2-slot bracket for 2 participants', () => {
      const participants = createParticipants(2);
      const mappings = createMappings(participants.map(p => p.id), catId);

      localStorage.setItem('ts_participants', JSON.stringify(participants));
      localStorage.setItem('ts_participant_categories', JSON.stringify(mappings));

      const bouts = mockStore.bouts.generateDraw(catId, 'Elimination', false);

      // 2 athletes -> 2 slots -> 1 bout in round 1, no further rounds
      expect(bouts.length).toBe(1);
      expect(bouts[0].round_no).toBe(1);
      expect(bouts[0].bout_no).toBe(1);
      expect(bouts[0].participant_a_id).toBe('part-1');
      expect(bouts[0].participant_b_id).toBe('part-2');
      expect(bouts[0].status).toBe('Scheduled');
      expect(bouts[0].winner_id).toBeNull();
    });

    it('generates correct brackets with byes (e.g. 3 participants)', () => {
      const participants = createParticipants(3);
      const mappings = createMappings(participants.map(p => p.id), catId);

      localStorage.setItem('ts_participants', JSON.stringify(participants));
      localStorage.setItem('ts_participant_categories', JSON.stringify(mappings));

      const bouts = mockStore.bouts.generateDraw(catId, 'Elimination', false);

      // 3 athletes -> 4 slots -> 2 bouts in round 1, 1 bout in round 2
      // total bouts = 3
      expect(bouts.length).toBe(3);

      const round1 = bouts.filter(b => b.round_no === 1);
      const round2 = bouts.filter(b => b.round_no === 2);

      expect(round1.length).toBe(2);
      expect(round2.length).toBe(1);

      // One of the round 1 matches should have a bye (Walkover)
      // Bracket list: [part-1, part-2, part-3, null]
      // Bout 1: part-1 vs part-2 (Scheduled)
      // Bout 2: part-3 vs null (Walkover, winner is part-3)
      expect(round1[0].participant_a_id).toBe('part-1');
      expect(round1[0].participant_b_id).toBe('part-2');
      expect(round1[0].status).toBe('Scheduled');
      expect(round1[0].winner_id).toBeNull();

      expect(round1[1].participant_a_id).toBe('part-3');
      expect(round1[1].participant_b_id).toBeNull();
      expect(round1[1].status).toBe('Walkover');
      expect(round1[1].winner_id).toBe('part-3');

      // Round 2 bout should start empty (scheduled, no participants initially assigned)
      expect(round2[0].participant_a_id).toBeNull();
      expect(round2[0].participant_b_id).toBeNull();
      expect(round2[0].status).toBe('Scheduled');
    });

    it('generates third place match when hasThirdPlace is true and count >= 4', () => {
      const participants = createParticipants(4);
      const mappings = createMappings(participants.map(p => p.id), catId);

      localStorage.setItem('ts_participants', JSON.stringify(participants));
      localStorage.setItem('ts_participant_categories', JSON.stringify(mappings));

      // 4 athletes -> 4 slots -> 2 bouts in round 1, 1 bout in round 2 (final), plus 1 3rd-place bout
      // total bouts = 4
      const bouts = mockStore.bouts.generateDraw(catId, 'Elimination', true);

      expect(bouts.length).toBe(4);

      const thirdPlaceBout = bouts.find(b => b.round_no === 99 && b.bout_no === 99);
      expect(thirdPlaceBout).toBeDefined();
      expect(thirdPlaceBout!.status).toBe('Scheduled');
      expect(thirdPlaceBout!.participant_a_id).toBeNull();
      expect(thirdPlaceBout!.participant_b_id).toBeNull();
    });

    it('does NOT generate third place match when count < 4', () => {
      const participants = createParticipants(3);
      const mappings = createMappings(participants.map(p => p.id), catId);

      localStorage.setItem('ts_participants', JSON.stringify(participants));
      localStorage.setItem('ts_participant_categories', JSON.stringify(mappings));

      const bouts = mockStore.bouts.generateDraw(catId, 'Elimination', true);

      const thirdPlaceBout = bouts.find(b => b.round_no === 99);
      expect(thirdPlaceBout).toBeUndefined();
    });
  });

  describe('Clear Draw', () => {
    it('removes all bouts for the specified category and leaves others intact', () => {
      // Setup bouts for two different categories
      const boutCat1: Bout = {
        id: 'b1', category_id: 'cat-1', bout_no: 1, round_no: 1,
        participant_a_id: 'p1', participant_b_id: 'p2', winner_id: null,
        score_a: 0, score_b: 0, status: 'Scheduled', tatami: 'Tatami 1'
      };
      const boutCat2: Bout = {
        id: 'b2', category_id: 'cat-2', bout_no: 1, round_no: 1,
        participant_a_id: 'p3', participant_b_id: 'p4', winner_id: null,
        score_a: 0, score_b: 0, status: 'Scheduled', tatami: 'Tatami 1'
      };

      localStorage.setItem('ts_bouts', JSON.stringify([boutCat1, boutCat2]));

      mockStore.bouts.clearDraw('cat-1');

      const remainingBouts = mockStore.bouts.list();
      expect(remainingBouts.length).toBe(1);
      expect(remainingBouts[0].category_id).toBe('cat-2');
    });
  });

  describe('Bout Result Progression', () => {
    it('advances winners correctly to the next round slots', () => {
      const participants = createParticipants(4);
      const mappings = createMappings(participants.map(p => p.id), catId);

      localStorage.setItem('ts_participants', JSON.stringify(participants));
      localStorage.setItem('ts_participant_categories', JSON.stringify(mappings));

      // 4 slots -> Round 1: Bout 1 (part-1 vs part-2) and Bout 2 (part-3 vs part-4)
      // Round 2: Bout 1 (winner of Bout 1 vs winner of Bout 2)
      mockStore.bouts.generateDraw(catId, 'Elimination', false);

      const bouts = mockStore.bouts.listForCategory(catId);
      const r1Bout1 = bouts.find(b => b.round_no === 1 && b.bout_no === 1)!;
      const r1Bout2 = bouts.find(b => b.round_no === 1 && b.bout_no === 2)!;
      const r2Bout = bouts.find(b => b.round_no === 2 && b.bout_no === 1)!;

      expect(r2Bout.participant_a_id).toBeNull();
      expect(r2Bout.participant_b_id).toBeNull();

      // Complete Bout 1 with winner part-1
      mockStore.bouts.updateBoutResult(r1Bout1.id, 'part-1', 4, 2);

      // Check that Bout 1 is marked Completed
      const boutsAfterB1 = mockStore.bouts.listForCategory(catId);
      const updatedR1Bout1 = boutsAfterB1.find(b => b.id === r1Bout1.id)!;
      expect(updatedR1Bout1.status).toBe('Completed');
      expect(updatedR1Bout1.winner_id).toBe('part-1');
      expect(updatedR1Bout1.score_a).toBe(4);
      expect(updatedR1Bout1.score_b).toBe(2);

      // Check that winner part-1 has advanced to Round 2, slot A (since bout_no 1 is odd)
      const updatedR2Bout1 = boutsAfterB1.find(b => b.id === r2Bout.id)!;
      expect(updatedR2Bout1.participant_a_id).toBe('part-1');
      expect(updatedR2Bout1.participant_b_id).toBeNull();

      // Complete Bout 2 with winner part-4
      mockStore.bouts.updateBoutResult(r1Bout2.id, 'part-4', 1, 3);

      // Check that winner part-4 has advanced to Round 2, slot B (since bout_no 2 is even)
      const boutsAfterB2 = mockStore.bouts.listForCategory(catId);
      const finalR2Bout = boutsAfterB2.find(b => b.id === r2Bout.id)!;
      expect(finalR2Bout.participant_a_id).toBe('part-1');
      expect(finalR2Bout.participant_b_id).toBe('part-4');
    });
  });
});
